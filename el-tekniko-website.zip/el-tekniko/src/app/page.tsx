'use client'

import { useEffect, useRef, useState } from 'react'
import Link from 'next/link'
import { ArrowRight, Star, Shield, Award, Zap, ChevronRight } from 'lucide-react'
import BookingModal from '@/components/BookingModal'

const MACHINES = [
  {
    slug: '7d-hifu',
    name: '7D HIFU',
    tagline: 'Face & Body Lifting',
    description: 'Non-invasive skin tightening with 7 cartridge depths. FDA-cleared technology.',
    treatments: ['Face Lifting', 'Neck Tightening', 'Body Contouring'],
    badge: 'Best Seller',
  },
  {
    slug: 'co2-fractional-laser',
    name: 'CO2 Fractional Laser',
    tagline: 'Skin Resurfacing',
    description: 'Advanced fractional CO2 for acne scars, wrinkles, and full skin renewal.',
    treatments: ['Acne Scars', 'Wrinkle Removal', 'Skin Renewal'],
    badge: 'High ROI',
  },
  {
    slug: 'cryolipolysis',
    name: 'Cryolipolysis',
    tagline: 'Fat Freezing',
    description: 'Freeze and eliminate stubborn fat cells permanently. Up to 4 handles simultaneously.',
    treatments: ['Fat Reduction', 'Body Sculpting', 'Love Handles'],
    badge: 'Popular',
  },
  {
    slug: 'rf-microneedling',
    name: 'RF Microneedling',
    tagline: 'Skin Rejuvenation',
    description: 'Fractional RF energy delivered via micro-needles for collagen induction.',
    treatments: ['Pore Tightening', 'Collagen Boost', 'Scar Revision'],
    badge: 'New',
  },
  {
    slug: 'diode-laser',
    name: 'Diode Laser',
    tagline: 'Hair Removal',
    description: '808nm diode laser for permanent hair reduction on all skin types.',
    treatments: ['Permanent Hair Removal', 'All Skin Types', 'Large Areas'],
    badge: null,
  },
  {
    slug: 'emsculpt',
    name: 'EMS Body Sculpt',
    tagline: 'Muscle Building',
    description: 'High-intensity electromagnetic stimulation builds muscle and burns fat simultaneously.',
    treatments: ['Abs Toning', 'Buttock Lift', 'Arm Toning'],
    badge: 'Trending',
  },
]

const STATS = [
  { value: 500, suffix: '+', label: 'Machines Deployed' },
  { value: 200, suffix: '+', label: 'Clinics Served' },
  { value: 12, suffix: '', label: 'Machine Categories' },
  { value: 98, suffix: '%', label: 'Client Satisfaction' },
]

const TESTIMONIALS = [
  {
    name: 'Dr. Maria Santos',
    clinic: 'Luminara Aesthetics, Makati',
    text: 'The 7D HIFU has been a game-changer for our clinic. ROI within 3 months. El Tekniko\'s after-sales support is unmatched.',
    rating: 5,
  },
  {
    name: 'Jen Reyes',
    clinic: 'Glow Studio, Cebu City',
    text: 'CO2 Fractional Laser was the best investment we made. Our acne scar clients are amazed with the results. Highly recommend!',
    rating: 5,
  },
  {
    name: 'Dr. Carlo Mendoza',
    clinic: 'The Skin Lab, BGC',
    text: 'Professional team, CE-certified equipment, and genuine warranty support. We\'ve purchased 4 machines from El Tekniko.',
    rating: 5,
  },
]

function CounterStat({ value, suffix, label }: { value: number; suffix: string; label: string }) {
  const [count, setCount] = useState(0)
  const ref = useRef<HTMLDivElement>(null)
  const started = useRef(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started.current) {
          started.current = true
          let start = 0
          const duration = 2000
          const step = (timestamp: number) => {
            if (!start) start = timestamp
            const progress = Math.min((timestamp - start) / duration, 1)
            setCount(Math.floor(progress * value))
            if (progress < 1) requestAnimationFrame(step)
          }
          requestAnimationFrame(step)
        }
      },
      { threshold: 0.5 }
    )
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [value])

  return (
    <div ref={ref} className="text-center">
      <div className="text-4xl md:text-5xl font-bold gradient-text mb-2">
        {count}{suffix}
      </div>
      <div className="text-sm text-gray-400 uppercase tracking-widest">{label}</div>
    </div>
  )
}

export default function HomePage() {
  const [bookingOpen, setBookingOpen] = useState(false)

  return (
    <>
      {/* HERO */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-dark-900 via-dark-800 to-dark-900" />
        <div className="absolute inset-0 opacity-20"
          style={{ backgroundImage: 'radial-gradient(circle at 20% 50%, rgba(201,168,76,0.15) 0%, transparent 50%), radial-gradient(circle at 80% 20%, rgba(201,168,76,0.1) 0%, transparent 40%)' }}
        />
        {/* Grid pattern */}
        <div className="absolute inset-0 opacity-5"
          style={{ backgroundImage: 'linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)', backgroundSize: '60px 60px' }}
        />

        <div className="relative z-10 max-w-6xl mx-auto px-6 text-center pt-24 pb-16">
          {/* Trust badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-gold-dim mb-8 text-sm text-gold-light">
            <Shield size={14} />
            CE & ISO Certified Machines · Philippines #1 Aesthetic Machine Supplier
          </div>

          <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-6">
            Premium Aesthetic<br />
            <span className="gradient-text">Machines</span> for Your Clinic
          </h1>

          <p className="text-lg md:text-xl text-gray-400 max-w-2xl mx-auto mb-10">
            7D HIFU, CO2 Fractional Laser, Cryolipolysis, RF Microneedling and more.
            Trusted by 200+ clinics across the Philippines.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button onClick={() => setBookingOpen(true)} className="btn-gold text-base px-8 py-4">
              Book a Free Demo <ArrowRight size={18} />
            </button>
            <Link href="/products" className="btn-outline-gold text-base px-8 py-4">
              View All Machines <ChevronRight size={18} />
            </Link>
          </div>

          {/* Quick trust row */}
          <div className="flex flex-wrap justify-center gap-6 mt-14 text-sm text-gray-500">
            {['CE Certified', 'ISO Approved', '1-Year Warranty', 'Free Training', 'After-Sales Support'].map(t => (
              <span key={t} className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-gold-500 inline-block" />
                {t}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* STATS */}
      <section className="py-16 border-y border-white/5 bg-dark-800">
        <div className="max-w-5xl mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-10">
          {STATS.map(s => (
            <CounterStat key={s.label} {...s} />
          ))}
        </div>
      </section>

      {/* MACHINES GRID */}
      <section className="section-pad max-w-7xl mx-auto px-6">
        <div className="text-center mb-14">
          <p className="text-gold-500 text-sm uppercase tracking-widest mb-3">Our Equipment</p>
          <h2 className="text-4xl md:text-5xl font-bold mb-4">Medical-Grade Machines</h2>
          <p className="text-gray-400 max-w-xl mx-auto">
            All machines are CE & ISO certified, come with comprehensive training and full after-sales support.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {MACHINES.map((m) => (
            <Link key={m.slug} href={`/products/${m.slug}`}>
              <div className="glass-card rounded-2xl p-6 hover:border-gold-dim transition-all duration-300 group cursor-pointer h-full flex flex-col">
                {/* Image placeholder */}
                <div className="w-full h-44 rounded-xl bg-dark-700 mb-5 flex items-center justify-center overflow-hidden relative">
                  <div className="absolute inset-0 bg-gradient-to-br from-gold-500/10 to-transparent" />
                  <Zap size={48} className="text-gold-500/30" />
                  {m.badge && (
                    <span className="absolute top-3 right-3 bg-gold-500 text-black text-xs font-bold px-3 py-1 rounded-full">
                      {m.badge}
                    </span>
                  )}
                </div>

                <p className="text-gold-500 text-xs uppercase tracking-widest mb-1">{m.tagline}</p>
                <h3 className="text-xl font-bold mb-2 group-hover:text-gold-400 transition-colors">{m.name}</h3>
                <p className="text-gray-400 text-sm mb-4 flex-grow">{m.description}</p>

                <div className="flex flex-wrap gap-2 mb-4">
                  {m.treatments.map(t => (
                    <span key={t} className="text-xs px-2 py-1 rounded-full bg-white/5 text-gray-400 border border-white/5">
                      {t}
                    </span>
                  ))}
                </div>

                <div className="flex items-center text-gold-500 text-sm font-medium group-hover:gap-3 gap-2 transition-all">
                  View details <ArrowRight size={15} />
                </div>
              </div>
            </Link>
          ))}
        </div>

        <div className="text-center mt-10">
          <Link href="/products" className="btn-outline-gold">
            See All Machines <ArrowRight size={16} />
          </Link>
        </div>
      </section>

      {/* WHY CHOOSE US */}
      <section className="section-pad bg-dark-800">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-14">
            <p className="text-gold-500 text-sm uppercase tracking-widest mb-3">Why El Tekniko</p>
            <h2 className="text-4xl font-bold">Built for Clinics, Backed by Expertise</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { icon: Shield, title: 'CE & ISO Certified', desc: 'Every machine meets international medical safety standards. FDA-cleared technologies you can trust.' },
              { icon: Award, title: '1-Year Full Warranty', desc: 'Comprehensive warranty with local technician support. Parts replacement included for major components.' },
              { icon: Zap, title: 'Free Training Included', desc: 'Full operator training for you and your staff included with every purchase. Protocol guides provided.' },
            ].map(({ icon: Icon, title, desc }) => (
              <div key={title} className="glass-card rounded-2xl p-7">
                <div className="w-12 h-12 rounded-xl bg-gold-500/10 flex items-center justify-center mb-5">
                  <Icon size={22} className="text-gold-500" />
                </div>
                <h3 className="text-lg font-bold mb-3">{title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="section-pad max-w-6xl mx-auto px-6">
        <div className="text-center mb-14">
          <p className="text-gold-500 text-sm uppercase tracking-widest mb-3">Client Stories</p>
          <h2 className="text-4xl font-bold">Trusted by 200+ Clinics</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((t) => (
            <div key={t.name} className="glass-card rounded-2xl p-6 flex flex-col">
              <div className="flex gap-1 mb-4">
                {Array.from({ length: t.rating }).map((_, i) => (
                  <Star key={i} size={14} className="text-gold-500 fill-gold-500" />
                ))}
              </div>
              <p className="text-gray-300 text-sm leading-relaxed mb-6 flex-grow">"{t.text}"</p>
              <div>
                <p className="font-semibold text-sm">{t.name}</p>
                <p className="text-gray-500 text-xs">{t.clinic}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA BANNER */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-gold-600/20 via-gold-500/10 to-gold-600/20" />
        <div className="absolute inset-0 border-y border-gold-dim" />
        <div className="relative z-10 text-center px-6">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Ready to Grow Your Clinic?
          </h2>
          <p className="text-gray-400 mb-8 text-lg max-w-xl mx-auto">
            Book a free machine demo today. We come to you — or join us at our Quezon City showroom.
          </p>
          <button onClick={() => setBookingOpen(true)} className="btn-gold text-lg px-10 py-5">
            Book Your Free Demo <ArrowRight size={20} />
          </button>
          <p className="text-gray-600 text-sm mt-4">No commitment required. Slots are limited.</p>
        </div>
      </section>

      <BookingModal open={bookingOpen} onClose={() => setBookingOpen(false)} />
    </>
  )
}
