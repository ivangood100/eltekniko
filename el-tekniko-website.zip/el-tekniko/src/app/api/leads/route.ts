import { NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { sendLeadNotification } from '@/lib/email'

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const { name, email, phone, clinicName, machine, budget, notes, source } = body

    if (!name || !phone) {
      return NextResponse.json({ error: 'Name and phone are required' }, { status: 400 })
    }

    const { data, error } = await supabaseAdmin
      .from('leads')
      .insert({
        name,
        email: email ?? null,
        phone,
        clinic_name: clinicName ?? null,
        machine_interest: machine ?? null,
        budget: budget ?? null,
        notes: notes ?? null,
        status: 'new',
        source: source ?? 'contact_form',
      })
      .select()
      .single()

    if (error) throw error

    // Notify sales team
    await sendLeadNotification({ name, email: email ?? '', phone, machine: machine ?? 'Not specified', source: source ?? 'contact_form' })

    return NextResponse.json({ success: true, leadId: data.id })
  } catch (err) {
    console.error('Lead capture error:', err)
    return NextResponse.json({ error: 'Failed to save inquiry' }, { status: 500 })
  }
}
