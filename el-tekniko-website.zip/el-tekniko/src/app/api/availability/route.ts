import { NextResponse } from 'next/server'
import { getAvailableSlots } from '@/lib/googleCalendar'

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url)
  const date = searchParams.get('date')

  if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    return NextResponse.json({ error: 'Invalid date format. Use YYYY-MM-DD' }, { status: 400 })
  }

  try {
    const availability = await getAvailableSlots(date)
    return NextResponse.json({ date, availability })
  } catch (err) {
    console.error('Availability check error:', err)
    // Fallback: return all slots as available
    const fallback = ['9:00 AM','10:00 AM','11:00 AM','1:00 PM','2:00 PM','3:00 PM','4:00 PM','5:00 PM']
      .map(time => ({ time, available: true }))
    return NextResponse.json({ date, availability: fallback })
  }
}
