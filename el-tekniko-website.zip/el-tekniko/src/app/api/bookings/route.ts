import { NextResponse } from 'next/server'
import { createBookingEvent } from '@/lib/googleCalendar'
import { supabaseAdmin } from '@/lib/supabase'
import { sendConfirmationEmail, sendLeadNotification } from '@/lib/email'

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const {
      clientName, email, phone, clinicName,
      machine, demoType, startTime, notes, budget, role,
    } = body

    if (!clientName || !email || !machine || !startTime) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    // 1. Create Google Calendar event
    const calEvent = await createBookingEvent({
      clientName, email, phone, clinicName,
      machine, demoType, startTime, notes,
    })

    // 2. Save to Supabase
    const { data: booking, error } = await supabaseAdmin
      .from('bookings')
      .insert({
        client_name: clientName,
        email,
        phone,
        clinic_name: clinicName,
        machine_interest: machine,
        demo_type: demoType,
        demo_datetime: startTime,
        notes,
        gcal_event_id: calEvent.id,
        meet_link: calEvent.hangoutLink ?? null,
        status: 'confirmed',
      })
      .select()
      .single()

    if (error) throw error

    // 3. Also save as lead
    await supabaseAdmin.from('leads').insert({
      name: clientName,
      email,
      phone,
      clinic_name: clinicName,
      machine_interest: machine,
      budget: budget ?? null,
      status: 'new',
      source: 'booking_form',
      notes: `Role: ${role ?? 'N/A'}. ${notes ?? ''}`.trim(),
    })

    // 4. Send confirmation email to client
    await sendConfirmationEmail({
      to: email,
      name: clientName,
      machine,
      datetime: startTime,
      demoType,
      meetLink: calEvent.hangoutLink,
    })

    // 5. Notify sales team
    await sendLeadNotification({
      name: clientName, email, phone, machine,
      source: 'booking_form',
    })

    return NextResponse.json({
      success: true,
      bookingId: booking.id,
      eventId: calEvent.id,
      meetLink: calEvent.hangoutLink ?? null,
    })
  } catch (err) {
    console.error('Booking error:', err)
    return NextResponse.json({ error: 'Booking failed. Please try again.' }, { status: 500 })
  }
}

export async function GET() {
  const { data } = await supabaseAdmin
    .from('bookings')
    .select('*')
    .order('demo_datetime', { ascending: true })
  return NextResponse.json(data)
}
