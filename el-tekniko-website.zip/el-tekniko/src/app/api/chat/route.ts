import { NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'

const SYSTEM_PROMPT = `You are "Tek" — the AI sales assistant for El Tekniko, a premium aesthetic salon machine supplier based in Quezon City, Philippines.

You help clinic owners, aestheticians, and practitioners choose the right aesthetic machines for their business.

Our machines include:
- 7D HIFU (Face & Body Lifting) — non-invasive skin tightening, 7 cartridge depths
- CO2 Fractional Laser — acne scars, wrinkles, full skin resurfacing
- Cryolipolysis (Fat Freezing) — permanent fat reduction, up to 4 handles
- RF Microneedling — collagen induction, pore tightening, scar revision
- Diode Laser (808nm) — permanent hair removal, all skin types
- EMS Body Sculpt — muscle building + fat burning simultaneously

RULES:
1. Be warm, professional, and concise. Max 3 short paragraphs per reply.
2. Ask qualifying questions: What treatments does their clinic offer? What's their budget range? Are they buying for themselves or reselling?
3. Never give exact prices — say "contact us for a personalized quote based on your needs."
4. After 2 back-and-forth exchanges, offer to connect them to a specialist via WhatsApp or book a free demo.
5. If they ask about financing: "Yes, we offer flexible payment terms — let's discuss what works for you."
6. If they ask about warranty: "All machines come with a 1-year full warranty and free operator training."
7. If they ask about location: "Our showroom is in Quezon City, Metro Manila. We also do virtual demos via Zoom."
8. Always end replies with a helpful question or a clear next step.
9. Keep responses SHORT — 2-4 sentences max unless explaining a machine.`

export async function POST(req: Request) {
  try {
    const { messages, sessionId } = await req.json()

    if (!messages || !Array.isArray(messages)) {
      return NextResponse.json({ error: 'Invalid messages format' }, { status: 400 })
    }

    // Build Gemini-compatible message history (skip first assistant message)
    const history = messages.slice(1).map((m: { role: string; content: string }) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }],
    }))

    // Call Gemini via Google AI Studio REST API
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${process.env.GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          system_instruction: {
            parts: [{ text: SYSTEM_PROMPT }],
          },
          contents: history,
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 300,
            topP: 0.9,
          },
        }),
      }
    )

    if (!response.ok) {
      throw new Error(`Gemini API error: ${response.status}`)
    }

    const data = await response.json()
    const reply = data.candidates?.[0]?.content?.parts?.[0]?.text ?? 
      "I'm having trouble connecting right now. Please reach us on WhatsApp for immediate assistance!"

    // Save chat session to Supabase (async, non-blocking)
    if (sessionId) {
      supabaseAdmin.from('chat_sessions').upsert({
        session_id: sessionId,
        messages,
        updated_at: new Date().toISOString(),
      }, { onConflict: 'session_id' }).then(() => {})
    }

    return NextResponse.json({ reply })
  } catch (err) {
    console.error('Chat API error:', err)
    return NextResponse.json(
      { reply: "Sorry, I'm having a connection issue. Please WhatsApp us directly at +63 9XX XXX XXXX for immediate help!" },
      { status: 200 } // Return 200 so UI shows message gracefully
    )
  }
}
