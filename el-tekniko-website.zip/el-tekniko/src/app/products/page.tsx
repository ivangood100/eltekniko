'use client'

import { useState } from 'react'
import Link from 'next/link'
import { ArrowRight, Zap, Filter } from 'lucide-react'
import BookingModal from '@/components/BookingModal'

const CATEGORIES = ['All', 'Face', 'Body', 'Skin', 'Hair']

const PRODUCTS = [
  {
    slug: '7d-hifu',
    name: '7D HIFU',
    tagline: 'Face & Body Lifting',
    category: 'Face',
    description: 'Non-invasive skin tightening and lifting with 7 cartridge depths. Targets SMAS layer for results comparable to surgical facelifts.',
    treatments: ['Face Lifting', 'Neck Tightening', 'Body Contouring', 'Double Chin'],
    specs: { cartridges: '7 depths', technology: 'Ultrasound HIFU', sessions: '1–2 per year' },
    badge: 'Best Seller',
    roi: 'High ROI',
  },
  {
    slug: 'co2-fractional-laser',
    name: 'CO2 Fractional Laser',
    tagline: 'Skin Resurfacing',
    category: 'Skin',
    description: 'Advanced fractional CO2 laser for acne scars, deep wrinkles, and full skin renewal. CE-certified, clinic-grade performance.',
    treatments: ['Acne Scars', 'Wrinkle Removal', 'Skin Renewal', 'Pore Minimizing'],
    specs: { wavelength: '10,600nm CO2', modes: 'Fractional + Ablative', downtime: '3–7 days' },
    badge: 'High ROI',
    roi: 'Premium',
  },
  {
    slug: 'cryolipolysis',
    name: 'Cryolipolysis',
    tagline: 'Fat Freezing',
    category: 'Body',
    description: 'Freeze and permanently eliminate stubborn fat cells. Up to 4 handles simultaneously for full-body treatment efficiency.',
    treatments: ['Fat Reduction', 'Body Sculpting', 'Love Handles', 'Thigh Slimming'],
    specs: { handles: 'Up to 4 simultaneous', temp: '-11°C to 5°C', session: '35–60 min' },
    badge: 'Popular',
    roi: 'High ROI',
  },
  {
    slug: 'rf-microneedling',
    name: 'RF Microneedling',
    tagline: 'Skin Rejuvenation',
    category: 'Skin',
    description: 'Fractional RF energy delivered via insulated micro-needles for deep collagen induction without surface damage.',
    treatments: ['Pore Tightening', 'Collagen Boost', 'Scar Revision', 'Stretch Marks'],
    specs: { needles: '25 / 49 / 81 pins', depth: '0.5–3.5mm', technology: 'Fractional RF' },
    badge: 'New',
    roi: 'Medium-High',
  },
  {
    slug: 'diode-laser',
    name: 'Diode Laser',
    tagline: 'Permanent Hair Removal',
    category: 'Hair',
    description: '808nm diode laser for safe and permanent hair reduction on all skin types. Large spot size for fast full-body treatments.',
    treatments: ['Permanent Hair Removal', 'All Skin Types', 'Full Body', 'Bikini Line'],
    specs: { wavelength: '808nm', spot: '12×12mm', cooling: 'Contact cooling' },
    badge: null,
    roi: 'High Volume',
  },
  {
    slug: 'emsculpt',
    name: 'EMS Body Sculpt',
    tagline: 'Muscle Building + Fat Burning',
    category: 'Body',
    description: 'High-intensity electromagnetic stimulation induces supramaximal muscle contractions — building muscle and burning fat simultaneously.',
    treatments: ['Abs Toning', 'Buttock Lift', 'Arm Toning', 'Calf Definition'],
    specs: { contractions: '20,000/session', technology: 'HIFEM', session: '30 min' },
    badge: 'Trending',
    roi: 'Premium',
  },
  {
    slug: 'ipl-photofacial',
    name: 'IPL Photofacial',
    tagline: 'Skin Brightening',
    category: 'Skin',
    description: 'Intense Pulsed Light targets pigmentation, redness, and vascular lesions for a clear, even complexion.',
    treatments: ['Pigmentation', 'Redness', 'Sun Damage', 'Rosacea'],
    specs: { spectrum: '560–1200nm', modes: 'IPL + SHR', session: '20–30 min' },
    badge: null,
    roi: 'Medium',
  },
  {
    slug: 'hifu-vaginal',
    name: 'Vaginal HIFU',
    tagline: 'Intimate Rejuvenation',
    category: 'Body',
    description: 'Non-invasive vaginal tightening and rejuvenation using focused ultrasound. Growing demand in premium women\'s wellness clinics.',
    treatments: ['Vaginal Tightening', 'Postpartum Recovery', 'Incontinence', 'Dryness'],
    specs: { technology: 'Focused Ultrasound', sessions: '1–3', downtime: 'Zero' },
    badge: 'Premium',
    roi: 'High Margin',
  },
]

export default function ProductsPage() {
  const [activeCategory, setActiveCategory] = useState('All')
  const [bookingOpen, setBookingOpen] = useState(false)

  const filtered = activeCategory === 'All'
    ? PRODUCTS
    : PRODUCTS.filter(p => p.category === activeCategory)

  return (
    <>
      <div className="pt-24 pb-16 max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-14">
          <p className="text-gold-500 text-sm uppercase tracking-widest mb-3">Our Equipment</p>
          <h1 className="text-5xl font-bold mb-4">Aesthetic Machines</h1>
          <p className="text-gray-400 max-w-xl mx-auto mb-8">
            CE & ISO certified. Every machine comes with comprehensive training, warranty, and after-sales support.
          </p>
          <button onClick={() => setBookingOpen(true)} className="btn-gold">
            Book a Free Demo <ArrowRight size={16} />
          </button>
        </div>

        {/* Category filter */}
        <div className="flex items-center gap-3 mb-10 flex-wrap">
          <Filter size={16} className="text-gray-500" />
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-5 py-2 rounded-full text-sm border transition-colors ${
                activeCategory === cat
                  ? 'border-gold-500 text-gold-400 bg-gold-500/10'
                  : 'border-white/10 text-gray-500 hover:border-white/20 hover:text-gray-300'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Products grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {filtered.map((p) => (
            <Link key={p.slug} href={`/products/${p.slug}`}>
              <div className="glass-card rounded-2xl p-5 hover:border-gold-dim transition-all duration-300 group cursor-pointer h-full flex flex-col">
                {/* Image area */}
                <div className="w-full h-36 rounded-xl bg-dark-700 mb-4 flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-gold-500/10 to-transparent" />
                  <Zap size={36} className="text-gold-500/30" />
                  <div className="absolute top-2 left-2 flex gap-1.5">
                    {p.badge && (
                      <span className="bg-gold-500 text-black text-xs font-bold px-2 py-0.5 rounded-full">
                        {p.badge}
                      </span>
                    )}
                  </div>
                  <span className="absolute bottom-2 right-2 text-xs px-2 py-0.5 rounded-full bg-white/5 text-gray-500 border border-white/5">
                    {p.roi}
                  </span>
                </div>

                <p className="text-gold-500 text-xs uppercase tracking-widest mb-1">{p.tagline}</p>
                <h3 className="font-bold text-base mb-2 group-hover:text-gold-400 transition-colors">{p.name}</h3>
                <p className="text-gray-500 text-xs leading-relaxed mb-3 flex-grow line-clamp-2">{p.description}</p>

                <div className="flex flex-wrap gap-1 mb-3">
                  {p.treatments.slice(0, 3).map(t => (
                    <span key={t} className="text-xs px-2 py-0.5 rounded-full bg-white/5 text-gray-500 border border-white/5">
                      {t}
                    </span>
                  ))}
                </div>

                <div className="flex items-center text-gold-500 text-xs font-medium gap-1.5 group-hover:gap-2.5 transition-all">
                  View details <ArrowRight size={13} />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      <BookingModal open={bookingOpen} onClose={() => setBookingOpen(false)} />
    </>
  )
}
