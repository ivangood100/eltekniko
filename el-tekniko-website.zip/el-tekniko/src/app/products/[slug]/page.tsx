'use client'

import { useState } from 'react'
import { useParams } from 'next/navigation'
import Link from 'next/link'
import { ArrowRight, ChevronDown, ChevronUp, Zap, Shield, Award, Phone } from 'lucide-react'
import BookingModal from '@/components/BookingModal'

const PRODUCTS: Record<string, {
  name: string; tagline: string; description: string; longDesc: string;
  treatments: string[]; specs: Record<string, string>;
  faqs: { q: string; a: string }[]; badge?: string;
}> = {
  '7d-hifu': {
    name: '7D HIFU',
    tagline: 'Face & Body Lifting',
    badge: 'Best Seller',
    description: 'Non-invasive skin tightening and lifting using focused ultrasound energy targeting the SMAS layer.',
    longDesc: 'The 7D HIFU machine uses High Intensity Focused Ultrasound to deliver precise energy at 7 different depths (1.5mm, 2.0mm, 3.0mm, 4.5mm, 6.0mm, 9.0mm, 13.0mm), targeting everything from superficial skin layers to the deep SMAS layer — the same layer addressed in surgical facelifts. Results are visible immediately and improve over 3–6 months as collagen production continues. Ideal for clinics offering premium anti-aging treatments.',
    treatments: ['Face Lifting', 'Neck Tightening', 'Body Contouring', 'Double Chin Reduction', 'Brow Lifting', 'Décolletage'],
    specs: {
      'Technology': 'High Intensity Focused Ultrasound (HIFU)',
      'Cartridge depths': '1.5 / 2.0 / 3.0 / 4.5 / 6.0 / 9.0 / 13.0mm',
      'Frequency': '3MHz / 7MHz',
      'Energy range': '0.1 – 2.0 J/cm²',
      'Shot lines': '11 lines per cartridge',
      'Screen': '10.4" touch display',
      'Sessions needed': '1–2 per year',
      'Downtime': 'Zero',
      'Certification': 'CE, ISO, FDA cleared',
    },
    faqs: [
      { q: 'How many sessions does a client need?', a: 'Most clients see excellent results with 1 session per year. Some clients with more advanced aging may benefit from 2 sessions, spaced 6 months apart.' },
      { q: 'Is it painful?', a: 'Clients feel a warm, tingling sensation during the procedure. Most describe it as comfortable to mildly uncomfortable. No anesthesia required.' },
      { q: 'What is the ROI for a clinic?', a: 'HIFU treatments are priced between ₱8,000–₱30,000 per session in Philippine clinics. Most clinics recover their machine investment within 3–6 months.' },
      { q: 'Does it come with training?', a: 'Yes — free comprehensive operator training is included with every purchase, both in-person and via detailed video protocols.' },
    ],
  },
  'co2-fractional-laser': {
    name: 'CO2 Fractional Laser',
    tagline: 'Skin Resurfacing',
    badge: 'High ROI',
    description: 'Advanced fractional CO2 laser for acne scars, deep wrinkles, and complete skin renewal.',
    longDesc: 'Our CO2 Fractional Laser delivers 10,600nm wavelength energy in a fractional pattern, creating thousands of micro-treatment zones while leaving surrounding tissue intact for faster healing. Suitable for acne scarring, deep wrinkles, surgical scars, stretch marks, and full skin resurfacing. With both fractional and full ablative modes, this machine covers a wide range of clinic treatments.',
    treatments: ['Acne Scars', 'Wrinkle Removal', 'Skin Renewal', 'Pore Minimizing', 'Surgical Scars', 'Stretch Marks'],
    specs: {
      'Wavelength': '10,600nm CO2',
      'Power': 'Up to 60W',
      'Modes': 'Fractional + Full Ablative',
      'Spot size': '0.12mm micro-beams',
      'Coverage': '5–100% density',
      'Scanner': '20×20mm to 50×50mm',
      'Downtime': '3–7 days',
      'Certification': 'CE, ISO',
    },
    faqs: [
      { q: 'What is the downtime for CO2 laser?', a: 'Fractional mode: 3–5 days of redness and peeling. Full ablative mode: 7–10 days. Clients should avoid direct sun for 2 weeks post-treatment.' },
      { q: 'Can it treat all skin types?', a: 'Best for Fitzpatrick skin types I–IV. For darker skin types (V–VI), settings must be adjusted carefully. Our training covers protocols for all skin types.' },
      { q: 'What is the treatment pricing in PH clinics?', a: 'CO2 Fractional Laser sessions are priced between ₱5,000–₱25,000 in Philippine clinics, depending on area and depth.' },
    ],
  },
  'cryolipolysis': {
    name: 'Cryolipolysis',
    tagline: 'Fat Freezing',
    badge: 'Popular',
    description: 'Freeze and permanently eliminate stubborn fat cells. Up to 4 handles simultaneously.',
    longDesc: 'Cryolipolysis works by cooling subcutaneous fat cells to -11°C, triggering apoptosis (natural cell death) without damaging surrounding tissue. The body naturally eliminates the dead fat cells over 4–12 weeks, with results lasting permanently if the client maintains their weight. With up to 4 applicator handles working simultaneously, clinics can treat multiple areas in a single session — maximizing revenue per hour.',
    treatments: ['Belly Fat', 'Love Handles', 'Thigh Slimming', 'Arm Reduction', 'Back Fat', 'Chin Fat'],
    specs: {
      'Technology': 'Controlled Cooling Cryolipolysis',
      'Temperature range': '-11°C to +5°C',
      'Handles': 'Up to 4 simultaneous',
      'Applicator sizes': 'Small / Medium / Large / Chin',
      'Session duration': '35–60 minutes per area',
      'Fat reduction': '20–25% per session',
      'Results visible': '4–12 weeks',
      'Certification': 'CE, ISO',
    },
    faqs: [
      { q: 'Is cryolipolysis permanent?', a: 'Yes — treated fat cells are permanently eliminated. However, remaining fat cells can still enlarge with weight gain, so maintaining a healthy lifestyle is recommended.' },
      { q: 'How many sessions are needed?', a: 'Most clients see visible results after 1 session. Clients wanting more dramatic results may do 2–3 sessions on the same area, spaced 6–8 weeks apart.' },
      { q: 'Is it safe?', a: 'Very safe. Cryolipolysis is FDA-cleared and has been performed on millions of clients globally. Common side effects include temporary redness, numbness, and mild bruising.' },
    ],
  },
}

function FaqItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false)
  return (
    <div className="border-b border-white/5 py-4">
      <button
        className="w-full flex items-center justify-between text-left gap-4"
        onClick={() => setOpen(!open)}
      >
        <span className="font-medium text-sm">{q}</span>
        {open ? <ChevronUp size={16} className="text-gold-500 flex-shrink-0" /> : <ChevronDown size={16} className="text-gray-500 flex-shrink-0" />}
      </button>
      {open && <p className="text-gray-400 text-sm mt-3 leading-relaxed">{a}</p>}
    </div>
  )
}

export default function ProductDetailPage() {
  const params = useParams()
  const slug = params.slug as string
  const [bookingOpen, setBookingOpen] = useState(false)
  const [inquiryForm, setInquiryForm] = useState({ name: '', phone: '', email: '' })
  const [inquirySent, setInquirySent] = useState(false)

  const product = PRODUCTS[slug] ?? {
    name: slug.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' '),
    tagline: 'Aesthetic Machine',
    description: 'Premium aesthetic machine. Contact us for full specifications.',
    longDesc: 'Contact our team for detailed information about this machine.',
    treatments: [],
    specs: {},
    faqs: [],
  }

  const handleInquiry = async (e: React.FormEvent) => {
    e.preventDefault()
    await fetch('/api/leads', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...inquiryForm, machine: product.name, source: 'product_page' }),
    })
    setInquirySent(true)
  }

  return (
    <>
      <div className="pt-24 max-w-7xl mx-auto px-6 pb-20">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-sm text-gray-500 mb-8">
          <Link href="/" className="hover:text-gold-400 transition-colors">Home</Link>
          <span>/</span>
          <Link href="/products" className="hover:text-gold-400 transition-colors">Machines</Link>
          <span>/</span>
          <span className="text-gray-300">{product.name}</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          {/* Main content */}
          <div className="lg:col-span-2">
            {/* Hero image */}
            <div className="w-full h-72 rounded-2xl bg-dark-700 flex items-center justify-center mb-6 relative overflow-hidden border border-white/5">
              <div className="absolute inset-0 bg-gradient-to-br from-gold-500/15 via-transparent to-transparent" />
              <Zap size={72} className="text-gold-500/20" />
              {product.badge && (
                <span className="absolute top-4 left-4 bg-gold-500 text-black text-xs font-bold px-3 py-1.5 rounded-full">
                  {product.badge}
                </span>
              )}
            </div>

            {/* Title */}
            <p className="text-gold-500 text-sm uppercase tracking-widest mb-2">{product.tagline}</p>
            <h1 className="text-4xl font-bold mb-4">{product.name}</h1>
            <p className="text-gray-400 leading-relaxed mb-6">{product.longDesc}</p>

            {/* Treatments */}
            <h2 className="text-lg font-bold mb-4">Treatments</h2>
            <div className="flex flex-wrap gap-2 mb-10">
              {product.treatments.map(t => (
                <span key={t} className="px-4 py-2 rounded-full border border-gold-dim text-gold-400 text-sm">
                  {t}
                </span>
              ))}
            </div>

            {/* Specs */}
            {Object.keys(product.specs).length > 0 && (
              <>
                <h2 className="text-lg font-bold mb-4">Technical Specifications</h2>
                <div className="glass-card rounded-2xl overflow-hidden mb-10">
                  {Object.entries(product.specs).map(([key, val], i) => (
                    <div key={key} className={`flex justify-between px-5 py-3.5 text-sm ${i % 2 === 0 ? 'bg-white/2' : ''}`}>
                      <span className="text-gray-500">{key}</span>
                      <span className="text-right font-medium text-gold-400">{val}</span>
                    </div>
                  ))}
                </div>
              </>
            )}

            {/* Trust badges */}
            <div className="flex flex-wrap gap-4 mb-10">
              {[
                { icon: Shield, text: 'CE & ISO Certified' },
                { icon: Award, text: '1-Year Warranty' },
                { icon: Zap, text: 'Free Training Included' },
              ].map(({ icon: Icon, text }) => (
                <div key={text} className="flex items-center gap-2 text-sm text-gray-400">
                  <Icon size={15} className="text-gold-500" />
                  {text}
                </div>
              ))}
            </div>

            {/* FAQs */}
            {product.faqs.length > 0 && (
              <>
                <h2 className="text-lg font-bold mb-2">Frequently Asked Questions</h2>
                <div className="mb-10">
                  {product.faqs.map(faq => <FaqItem key={faq.q} {...faq} />)}
                </div>
              </>
            )}
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 space-y-4">
              {/* Book demo card */}
              <div className="glass-card rounded-2xl p-6">
                <h3 className="font-bold text-lg mb-2">Get a Free Demo</h3>
                <p className="text-gray-500 text-sm mb-5">
                  See this machine in action at our Quezon City showroom or via Zoom. No commitment required.
                </p>
                <button onClick={() => setBookingOpen(true)} className="btn-gold w-full justify-center mb-3">
                  Book Demo <ArrowRight size={16} />
                </button>
                <a
                  href={`https://wa.me/${process.env.NEXT_PUBLIC_WHATSAPP_NUMBER ?? '639XXXXXXXXX'}?text=Hi! I'm interested in the ${product.name}. Can you give me more details?`}
                  target="_blank" rel="noreferrer"
                  className="btn-outline-gold w-full justify-center"
                >
                  WhatsApp Us
                </a>
              </div>

              {/* Quick inquiry form */}
              <div className="glass-card rounded-2xl p-6">
                <h3 className="font-bold mb-4">Quick Inquiry</h3>
                {inquirySent ? (
                  <div className="text-center py-4">
                    <p className="text-gold-400 font-medium mb-1">Inquiry received!</p>
                    <p className="text-gray-500 text-sm">Our team will contact you within 24 hours.</p>
                  </div>
                ) : (
                  <form onSubmit={handleInquiry} className="space-y-3">
                    <input className="input-dark text-sm py-2.5" placeholder="Your name *" value={inquiryForm.name} onChange={e => setInquiryForm(f => ({ ...f, name: e.target.value }))} required />
                    <input className="input-dark text-sm py-2.5" placeholder="Mobile number *" type="tel" value={inquiryForm.phone} onChange={e => setInquiryForm(f => ({ ...f, phone: e.target.value }))} required />
                    <input className="input-dark text-sm py-2.5" placeholder="Email address" type="email" value={inquiryForm.email} onChange={e => setInquiryForm(f => ({ ...f, email: e.target.value }))} />
                    <button type="submit" className="btn-gold w-full justify-center text-sm py-2.5">
                      Send Inquiry
                    </button>
                    <p className="text-gray-600 text-xs text-center">We'll reply within 24 hours</p>
                  </form>
                )}
              </div>

              {/* Call to action */}
              <div className="glass-card rounded-2xl p-5 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gold-500/10 flex items-center justify-center flex-shrink-0">
                  <Phone size={16} className="text-gold-500" />
                </div>
                <div>
                  <p className="text-sm font-medium">Call us directly</p>
                  <a href="tel:+639XXXXXXXXX" className="text-gold-400 text-sm">+63 9XX XXX XXXX</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <BookingModal open={bookingOpen} onClose={() => setBookingOpen(false)} />
    </>
  )
}
