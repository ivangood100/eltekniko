import { Shield, Award, Zap, Users, MapPin, ArrowRight } from 'lucide-react'
import Link from 'next/link'

export default function AboutPage() {
  return (
    <div className="pt-24 pb-20">
      {/* Hero */}
      <section className="max-w-5xl mx-auto px-6 text-center mb-20">
        <p className="text-gold-500 text-sm uppercase tracking-widest mb-3">Our Story</p>
        <h1 className="text-5xl font-bold mb-6">About El Tekniko</h1>
        <p className="text-gray-400 text-lg max-w-2xl mx-auto leading-relaxed">
          We started El Tekniko with one mission: give Filipino clinic owners access to the same medical-grade aesthetic machines used in top clinics worldwide — at fair prices, with real after-sales support.
        </p>
      </section>

      {/* Mission */}
      <section className="bg-dark-800 py-20 mb-20">
        <div className="max-w-5xl mx-auto px-6 grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-gold-500 text-sm uppercase tracking-widest mb-4">Our Mission</p>
            <h2 className="text-3xl font-bold mb-5">Empowering Clinics Across the Philippines</h2>
            <p className="text-gray-400 leading-relaxed mb-4">
              The Philippine aesthetic industry is one of the fastest-growing in Southeast Asia. Yet many clinic owners struggle to access reliable, certified equipment with proper training and support.
            </p>
            <p className="text-gray-400 leading-relaxed">
              El Tekniko bridges that gap — sourcing only CE & ISO certified machines, providing hands-on training, and standing behind every machine we sell with a 1-year full warranty.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {[
              { icon: Shield, label: 'CE & ISO Certified', desc: 'Every machine meets international standards' },
              { icon: Award, label: '1-Year Warranty', desc: 'Full parts and labor coverage' },
              { icon: Zap, label: 'Free Training', desc: 'Comprehensive operator certification' },
              { icon: Users, label: '200+ Clinics', desc: 'Trusted across the Philippines' },
            ].map(({ icon: Icon, label, desc }) => (
              <div key={label} className="glass-card rounded-xl p-4">
                <Icon size={20} className="text-gold-500 mb-2" />
                <p className="font-semibold text-sm mb-1">{label}</p>
                <p className="text-gray-500 text-xs">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="max-w-5xl mx-auto px-6 mb-20">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold">Why Clinics Choose Us</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { title: 'Certified Quality', body: 'We only carry machines with CE, ISO, and where applicable, FDA clearance. No gray-market equipment. Every certification is verifiable.' },
            { title: 'Real After-Sales', body: 'Our technicians are based in the Philippines. Spare parts are stocked locally. If something goes wrong, we fix it fast — not after months of shipping delays.' },
            { title: 'Honest Guidance', body: 'We help you choose the right machine for your clinic\'s treatment menu and budget — not the most expensive one. Our goal is your long-term success.' },
          ].map(({ title, body }) => (
            <div key={title} className="glass-card rounded-2xl p-6">
              <h3 className="font-bold text-lg mb-3">{title}</h3>
              <p className="text-gray-400 text-sm leading-relaxed">{body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Location */}
      <section className="max-w-5xl mx-auto px-6 mb-20">
        <div className="glass-card rounded-2xl p-8 flex flex-col md:flex-row gap-8 items-start">
          <div className="flex-1">
            <p className="text-gold-500 text-sm uppercase tracking-widest mb-3">Visit Us</p>
            <h2 className="text-2xl font-bold mb-4">Our Showroom</h2>
            <p className="text-gray-400 text-sm leading-relaxed mb-5">
              Our Quezon City showroom has demo units of all major machines available for hands-on testing. Book a visit and see the technology in action before you commit.
            </p>
            <div className="flex items-center gap-2 text-gray-400 text-sm mb-2">
              <MapPin size={15} className="text-gold-500" /> Quezon City, Metro Manila, Philippines
            </div>
            <p className="text-gray-500 text-xs">Monday – Saturday · 9:00 AM – 6:00 PM</p>
          </div>
          <div className="flex flex-col gap-3 min-w-[180px]">
            <Link href="/contact" className="btn-gold justify-center">
              Book a Showroom Visit <ArrowRight size={15} />
            </Link>
            <a href="https://maps.google.com/?q=Quezon+City+Metro+Manila" target="_blank" rel="noreferrer"
              className="btn-outline-gold justify-center text-sm">
              Get Directions
            </a>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="text-center px-6">
        <h2 className="text-3xl font-bold mb-4">Ready to Talk Machines?</h2>
        <p className="text-gray-400 mb-8">Book a free demo or send us an inquiry — no pressure, no hard sell.</p>
        <Link href="/contact" className="btn-gold text-base px-8 py-4">
          Get in Touch <ArrowRight size={18} />
        </Link>
      </section>
    </div>
  )
}
