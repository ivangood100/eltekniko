import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import ChatWidget from '@/components/ChatWidget'
import WhatsAppButton from '@/components/WhatsAppButton'

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
})

export const metadata: Metadata = {
  title: 'El Tekniko | Premium Aesthetic Salon Machines Philippines',
  description:
    'Supplier of 7D HIFU, CO2 Fractional Laser, Cryolipolysis, RF Microneedling and more. CE & ISO certified. Serving clinics and med-spas across the Philippines.',
  keywords:
    '7D HIFU machine Philippines, CO2 fractional laser Philippines, aesthetic machine supplier, salon equipment PH, El Tekniko',
  openGraph: {
    title: 'El Tekniko | Premium Aesthetic Salon Machines Philippines',
    description: 'CE & ISO certified aesthetic machines. Free demo booking for clinics.',
    url: 'https://eltekniko.com',
    siteName: 'El Tekniko',
    locale: 'en_PH',
    type: 'website',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={inter.variable}>
      <body>
        <Navbar />
        <main>{children}</main>
        <Footer />
        <ChatWidget />
        <WhatsAppButton />
      </body>
    </html>
  )
}
