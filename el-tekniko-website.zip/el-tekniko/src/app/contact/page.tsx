'use client'

import { useState } from 'react'
import { MapPin, Phone, Mail, Clock, CheckCircle, ArrowRight } from 'lucide-react'
import BookingModal from '@/components/BookingModal'

const MACHINES = ['7D HIFU', 'CO2 Fractional Laser', 'Cryolipolysis', 'RF Microneedling', 'Diode Laser', 'EMS Body Sculpt', 'Multiple / Not sure yet']

export default function ContactPage() {
  const [bookingOpen, setBookingOpen] = useState(false)
  const [form, setForm] = useState({ name: '', email: '', phone: '', clinicName: '', machine: '', budget: '', message: '' })
  const [sent, setSent] = useState(false)
  const [loading, setLoading] = useState(false)

  const set = (key: string, val: string) => setForm(f => ({ ...f, [key]: val }))

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, notes: form.message, source: 'contact_page' }),
      })
      setSent(true)
    } catch {
      alert('Something went wrong. Please reach us on WhatsApp.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      <div className="pt-24 pb-20 max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="text-gold-500 text-sm uppercase tracking-widest mb-3">Get in Touch</p>
          <h1 className="text-5xl font-bold mb-4">Contact El Tekniko</h1>
          <p className="text-gray-400 max-w-xl mx-auto">
            Interested in a machine? Have questions? Our team is ready to help you find the right solution for your clinic.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-10">
          {/* Inquiry form */}
          <div className="lg:col-span-3">
            <div className="glass-card rounded-2xl p-8">
              <h2 className="text-xl font-bold mb-6">Send an Inquiry</h2>

              {sent ? (
                <div className="text-center py-12">
                  <CheckCircle size={56} className="text-gold-500 mx-auto mb-4" />
                  <h3 className="text-xl font-bold mb-2">Message Received!</h3>
                  <p className="text-gray-400 text-sm">Our team will get back to you within 24 hours via phone or email.</p>
                  <button onClick={() => setBookingOpen(true)} className="btn-gold mt-6">
                    Book a Demo Instead <ArrowRight size={16} />
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs text-gray-500 mb-1.5 block font-medium">Full name *</label>
                      <input className="input-dark" placeholder="Dr. Maria Santos" value={form.name} onChange={e => set('name', e.target.value)} required />
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 mb-1.5 block font-medium">Mobile number *</label>
                      <input className="input-dark" type="tel" placeholder="+63 9XX XXX XXXX" value={form.phone} onChange={e => set('phone', e.target.value)} required />
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 mb-1.5 block font-medium">Email address</label>
                    <input className="input-dark" type="email" placeholder="maria@yourclinic.com" value={form.email} onChange={e => set('email', e.target.value)} />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 mb-1.5 block font-medium">Clinic / business name</label>
                    <input className="input-dark" placeholder="Luminara Aesthetics" value={form.clinicName} onChange={e => set('clinicName', e.target.value)} />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 mb-1.5 block font-medium">Machine of interest</label>
                    <select className="input-dark" value={form.machine} onChange={e => set('machine', e.target.value)}>
                      <option value="">Select a machine...</option>
                      {MACHINES.map(m => <option key={m} value={m}>{m}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 mb-1.5 block font-medium">Budget range</label>
                    <select className="input-dark" value={form.budget} onChange={e => set('budget', e.target.value)}>
                      <option value="">Select budget range...</option>
                      <option>Under ₱100,000</option>
                      <option>₱100,000 – ₱300,000</option>
                      <option>₱300,000 – ₱500,000</option>
                      <option>₱500,000 – ₱1,000,000</option>
                      <option>Above ₱1,000,000</option>
                      <option>Financing needed</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 mb-1.5 block font-medium">Message / questions</label>
                    <textarea className="input-dark resize-none" rows={4} placeholder="Tell us about your clinic, treatments you offer, and what you're looking for..." value={form.message} onChange={e => set('message', e.target.value)} />
                  </div>
                  <button type="submit" disabled={loading} className="btn-gold w-full justify-center py-3.5 disabled:opacity-60">
                    {loading ? 'Sending...' : 'Send Inquiry'}
                  </button>
                  <p className="text-center text-gray-600 text-xs">We reply within 24 hours · No spam ever</p>
                </form>
              )}
            </div>
          </div>

          {/* Info sidebar */}
          <div className="lg:col-span-2 space-y-5">
            {/* Book demo CTA */}
            <div className="glass-card rounded-2xl p-6 border border-gold-dim">
              <p className="text-gold-500 text-xs uppercase tracking-widest mb-2">Fastest way to connect</p>
              <h3 className="font-bold text-lg mb-3">Book a Free Machine Demo</h3>
              <p className="text-gray-400 text-sm mb-5">See the machines in action at our QC showroom or via Zoom. Slots are limited each month.</p>
              <button onClick={() => setBookingOpen(true)} className="btn-gold w-full justify-center">
                Book Now — It's Free <ArrowRight size={16} />
              </button>
            </div>

            {/* Contact details */}
            <div className="glass-card rounded-2xl p-6 space-y-5">
              <h3 className="font-bold">Contact Details</h3>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <MapPin size={16} className="text-gold-500 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-medium">Showroom</p>
                    <p className="text-gray-500 text-sm">Quezon City, Metro Manila<br />Philippines</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Phone size={16} className="text-gold-500 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-medium">Phone / WhatsApp</p>
                    <a href="tel:+639XXXXXXXXX" className="text-gold-400 text-sm">+63 9XX XXX XXXX</a>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Mail size={16} className="text-gold-500 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-medium">Email</p>
                    <a href="mailto:sales@eltekniko.com" className="text-gold-400 text-sm">sales@eltekniko.com</a>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Clock size={16} className="text-gold-500 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-medium">Business Hours</p>
                    <p className="text-gray-500 text-sm">Mon–Sat: 9:00 AM – 6:00 PM<br />Sunday: Closed</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Map embed placeholder */}
            <div className="glass-card rounded-2xl overflow-hidden h-48 flex items-center justify-center">
              <div className="text-center text-gray-600 text-sm">
                <MapPin size={24} className="mx-auto mb-2 text-gray-700" />
                <p>Quezon City, Metro Manila</p>
                <a
                  href="https://maps.google.com/?q=Quezon+City+Metro+Manila+Philippines"
                  target="_blank" rel="noreferrer"
                  className="text-gold-500 text-xs mt-1 inline-block hover:underline"
                >
                  Open in Google Maps →
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      <BookingModal open={bookingOpen} onClose={() => setBookingOpen(false)} />
    </>
  )
}
