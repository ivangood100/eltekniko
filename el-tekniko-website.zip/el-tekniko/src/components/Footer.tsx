import Link from 'next/link'
import { MapPin, Phone, Mail, Instagram, Facebook } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="bg-dark-800 border-t border-white/5 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div className="md:col-span-1">
            <Link href="/" className="text-xl font-bold">
              El <span className="gradient-text">Tekniko</span>
            </Link>
            <p className="text-gray-500 text-sm mt-4 leading-relaxed">
              Premium aesthetic salon machines for clinics and med-spas across the Philippines.
              CE & ISO certified.
            </p>
            <div className="flex gap-4 mt-5">
              <a href="https://facebook.com" target="_blank" rel="noreferrer"
                className="w-9 h-9 rounded-lg bg-white/5 flex items-center justify-center hover:bg-gold-500/20 hover:text-gold-400 transition-colors text-gray-500">
                <Facebook size={16} />
              </a>
              <a href="https://instagram.com" target="_blank" rel="noreferrer"
                className="w-9 h-9 rounded-lg bg-white/5 flex items-center justify-center hover:bg-gold-500/20 hover:text-gold-400 transition-colors text-gray-500">
                <Instagram size={16} />
              </a>
            </div>
          </div>

          {/* Machines */}
          <div>
            <h4 className="text-sm font-semibold mb-4 text-white/80 uppercase tracking-wider">Machines</h4>
            <ul className="space-y-2.5">
              {['7D HIFU', 'CO2 Fractional Laser', 'Cryolipolysis', 'RF Microneedling', 'Diode Laser', 'EMS Body Sculpt'].map(m => (
                <li key={m}>
                  <Link href="/products" className="text-sm text-gray-500 hover:text-gold-400 transition-colors">
                    {m}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="text-sm font-semibold mb-4 text-white/80 uppercase tracking-wider">Company</h4>
            <ul className="space-y-2.5">
              {[
                { href: '/about', label: 'About Us' },
                { href: '/blog', label: 'Resources' },
                { href: '/contact', label: 'Contact' },
                { href: '/contact', label: 'Book a Demo' },
              ].map(l => (
                <li key={l.label}>
                  <Link href={l.href} className="text-sm text-gray-500 hover:text-gold-400 transition-colors">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-sm font-semibold mb-4 text-white/80 uppercase tracking-wider">Contact</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-2.5 text-sm text-gray-500">
                <MapPin size={15} className="text-gold-500 mt-0.5 flex-shrink-0" />
                Quezon City, Metro Manila, Philippines
              </li>
              <li>
                <a href="tel:+639XXXXXXXXX" className="flex items-center gap-2.5 text-sm text-gray-500 hover:text-gold-400 transition-colors">
                  <Phone size={15} className="text-gold-500" />
                  +63 9XX XXX XXXX
                </a>
              </li>
              <li>
                <a href="mailto:sales@eltekniko.com" className="flex items-center gap-2.5 text-sm text-gray-500 hover:text-gold-400 transition-colors">
                  <Mail size={15} className="text-gold-500" />
                  sales@eltekniko.com
                </a>
              </li>
            </ul>
            <div className="mt-5 flex flex-wrap gap-2">
              {['CE', 'ISO', 'FDA'].map(badge => (
                <span key={badge} className="text-xs px-3 py-1 rounded-full border border-gold-dim text-gold-500 font-medium">
                  {badge} Certified
                </span>
              ))}
            </div>
          </div>
        </div>

        <div className="border-t border-white/5 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-gray-600 text-sm">© {new Date().getFullYear()} El Tekniko. All rights reserved.</p>
          <p className="text-gray-700 text-xs">Premium aesthetic machine supplier · Philippines</p>
        </div>
      </div>
    </footer>
  )
}
