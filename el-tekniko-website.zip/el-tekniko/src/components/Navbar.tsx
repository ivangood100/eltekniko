'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Menu, X, Phone } from 'lucide-react'

const LINKS = [
  { href: '/products', label: 'Machines' },
  { href: '/about', label: 'About' },
  { href: '/blog', label: 'Resources' },
  { href: '/contact', label: 'Contact' },
]

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-dark-900/95 backdrop-blur-md border-b border-white/5' : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2">
          <span className="text-xl font-bold">
            El <span className="gradient-text">Tekniko</span>
          </span>
        </Link>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-8">
          {LINKS.map(l => (
            <Link
              key={l.href}
              href={l.href}
              className="text-sm text-gray-400 hover:text-white transition-colors underline-gold"
            >
              {l.label}
            </Link>
          ))}
        </nav>

        {/* Desktop CTA */}
        <div className="hidden md:flex items-center gap-3">
          <a
            href="tel:+639XXXXXXXXX"
            className="flex items-center gap-2 text-sm text-gray-400 hover:text-gold-400 transition-colors"
          >
            <Phone size={14} />
            +63 9XX XXX XXXX
          </a>
          <Link href="/contact" className="btn-gold py-2 px-5 text-sm">
            Book Demo
          </Link>
        </div>

        {/* Mobile menu button */}
        <button
          className="md:hidden text-gray-400 hover:text-white"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          {menuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="md:hidden bg-dark-900/98 backdrop-blur-md border-b border-white/5 px-6 py-6">
          <nav className="flex flex-col gap-4 mb-6">
            {LINKS.map(l => (
              <Link
                key={l.href}
                href={l.href}
                className="text-gray-300 hover:text-white text-base py-1"
                onClick={() => setMenuOpen(false)}
              >
                {l.label}
              </Link>
            ))}
          </nav>
          <Link
            href="/contact"
            className="btn-gold w-full justify-center py-3"
            onClick={() => setMenuOpen(false)}
          >
            Book a Free Demo
          </Link>
        </div>
      )}
    </header>
  )
}
