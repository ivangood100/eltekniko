'use client'

import { useState } from 'react'
import { X, ChevronRight, ChevronLeft, Calendar, CheckCircle, Loader2 } from 'lucide-react'

interface BookingModalProps {
  open: boolean
  onClose: () => void
}

const MACHINES = [
  '7D HIFU (Face & Body)',
  'CO2 Fractional Laser',
  'Cryolipolysis (Fat Freezing)',
  'RF Microneedling',
  'Diode Laser (Hair Removal)',
  'EMS Body Sculpt',
  'Multiple machines',
]

const BUDGETS = [
  'Under ₱100,000',
  '₱100,000 – ₱300,000',
  '₱300,000 – ₱500,000',
  '₱500,000 – ₱1,000,000',
  'Above ₱1,000,000',
  'Financing needed',
]

const TIME_SLOTS = ['9:00 AM', '10:00 AM', '11:00 AM', '1:00 PM', '2:00 PM', '3:00 PM', '4:00 PM', '5:00 PM']

function getNextDays(count: number) {
  const days: Date[] = []
  const now = new Date()
  for (let i = 1; days.length < count; i++) {
    const d = new Date(now)
    d.setDate(now.getDate() + i)
    if (d.getDay() !== 0) days.push(d) // skip Sundays
  }
  return days
}

export default function BookingModal({ open, onClose }: BookingModalProps) {
  const [step, setStep] = useState(1)
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [availableSlots, setAvailableSlots] = useState<{ time: string; available: boolean }[]>([])
  const [loadingSlots, setLoadingSlots] = useState(false)

  const [form, setForm] = useState({
    clientName: '',
    email: '',
    phone: '',
    clinicName: '',
    role: 'Clinic Owner',
    machine: '',
    demoType: 'In-person',
    budget: '',
    selectedDate: '',
    selectedTime: '',
    notes: '',
  })

  const days = getNextDays(14)

  const set = (key: string, val: string) => setForm(f => ({ ...f, [key]: val }))

  const fetchAvailability = async (date: string) => {
    setLoadingSlots(true)
    try {
      const res = await fetch(`/api/availability?date=${date}`)
      const data = await res.json()
      setAvailableSlots(data.availability || TIME_SLOTS.map(t => ({ time: t, available: true })))
    } catch {
      setAvailableSlots(TIME_SLOTS.map(t => ({ time: t, available: true })))
    } finally {
      setLoadingSlots(false)
    }
  }

  const handleDateSelect = (date: Date) => {
    const iso = date.toISOString().split('T')[0]
    set('selectedDate', iso)
    set('selectedTime', '')
    fetchAvailability(iso)
  }

  const handleSubmit = async () => {
    setLoading(true)
    try {
      const startTime = `${form.selectedDate}T${convertTo24h(form.selectedTime)}:00+08:00`
      await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, startTime }),
      })
      setSuccess(true)
    } catch (err) {
      alert('Something went wrong. Please try again or contact us via WhatsApp.')
    } finally {
      setLoading(false)
    }
  }

  const handleClose = () => {
    onClose()
    setTimeout(() => { setStep(1); setSuccess(false); setForm({ clientName: '', email: '', phone: '', clinicName: '', role: 'Clinic Owner', machine: '', demoType: 'In-person', budget: '', selectedDate: '', selectedTime: '', notes: '' }) }, 300)
  }

  if (!open) return null

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.8)', backdropFilter: 'blur(8px)' }}>
      <div className="w-full max-w-lg bg-dark-800 border border-white/10 rounded-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/5">
          <div>
            <h2 className="font-bold text-lg">Book a Free Demo</h2>
            {!success && <p className="text-gray-500 text-xs mt-0.5">Step {step} of 3</p>}
          </div>
          <button onClick={handleClose} className="text-gray-500 hover:text-white transition-colors">
            <X size={20} />
          </button>
        </div>

        {/* Progress bar */}
        {!success && (
          <div className="h-0.5 bg-white/5">
            <div className="h-full bg-gold-500 transition-all duration-300" style={{ width: `${(step / 3) * 100}%` }} />
          </div>
        )}

        <div className="p-6 max-h-[70vh] overflow-y-auto">
          {success ? (
            <div className="text-center py-8">
              <CheckCircle size={56} className="text-gold-500 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Demo Booked!</h3>
              <p className="text-gray-400 text-sm mb-1">A confirmation email has been sent to <strong className="text-white">{form.email}</strong></p>
              <p className="text-gray-400 text-sm mb-6">Your demo is added to our Google Calendar. We'll see you soon!</p>
              <div className="glass-card rounded-xl p-4 text-sm text-left space-y-2">
                <div className="flex justify-between"><span className="text-gray-500">Machine</span><span className="text-gold-400">{form.machine}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Date</span><span>{form.selectedDate}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Time</span><span>{form.selectedTime}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Type</span><span>{form.demoType}</span></div>
              </div>
              <button onClick={handleClose} className="btn-gold mt-6 w-full justify-center">Done</button>
            </div>
          ) : step === 1 ? (
            <div className="space-y-4">
              <p className="text-sm text-gray-400 mb-6">Tell us about yourself and your clinic.</p>
              <div className="grid grid-cols-1 gap-4">
                <div>
                  <label className="text-xs text-gray-500 mb-1.5 block font-medium">Full name *</label>
                  <input className="input-dark" placeholder="Dr. Maria Santos" value={form.clientName} onChange={e => set('clientName', e.target.value)} />
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1.5 block font-medium">Email address *</label>
                  <input className="input-dark" type="email" placeholder="maria@luminara.com" value={form.email} onChange={e => set('email', e.target.value)} />
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1.5 block font-medium">Mobile number *</label>
                  <input className="input-dark" type="tel" placeholder="+63 9XX XXX XXXX" value={form.phone} onChange={e => set('phone', e.target.value)} />
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1.5 block font-medium">Clinic / business name</label>
                  <input className="input-dark" placeholder="Luminara Aesthetics" value={form.clinicName} onChange={e => set('clinicName', e.target.value)} />
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1.5 block font-medium">I am a</label>
                  <div className="flex flex-wrap gap-2">
                    {['Clinic Owner', 'Practitioner', 'Distributor', 'Personal'].map(r => (
                      <button key={r} type="button"
                        onClick={() => set('role', r)}
                        className={`text-xs px-4 py-2 rounded-full border transition-colors ${form.role === r ? 'border-gold-500 text-gold-400 bg-gold-500/10' : 'border-white/10 text-gray-500 hover:border-white/20'}`}>
                        {r}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ) : step === 2 ? (
            <div className="space-y-4">
              <p className="text-sm text-gray-400 mb-6">Choose your machine and preferred demo slot.</p>
              <div>
                <label className="text-xs text-gray-500 mb-1.5 block font-medium">Machine of interest *</label>
                <select className="input-dark" value={form.machine} onChange={e => set('machine', e.target.value)}>
                  <option value="">Select a machine...</option>
                  {MACHINES.map(m => <option key={m} value={m}>{m}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs text-gray-500 mb-1.5 block font-medium">Budget range</label>
                <select className="input-dark" value={form.budget} onChange={e => set('budget', e.target.value)}>
                  <option value="">Select budget range...</option>
                  {BUDGETS.map(b => <option key={b} value={b}>{b}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs text-gray-500 mb-2 block font-medium">Demo type</label>
                <div className="flex gap-3">
                  {['In-person', 'Virtual (Zoom)'].map(type => (
                    <button key={type} type="button" onClick={() => set('demoType', type)}
                      className={`flex-1 py-2.5 rounded-xl text-sm border transition-colors ${form.demoType === type ? 'border-gold-500 text-gold-400 bg-gold-500/10' : 'border-white/10 text-gray-500'}`}>
                      {type}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-xs text-gray-500 mb-2 block font-medium">
                  <Calendar size={12} className="inline mr-1" /> Select date
                </label>
                <div className="flex gap-2 overflow-x-auto pb-2">
                  {days.map(d => {
                    const iso = d.toISOString().split('T')[0]
                    const isSelected = form.selectedDate === iso
                    return (
                      <button key={iso} type="button" onClick={() => handleDateSelect(d)}
                        className={`flex-shrink-0 flex flex-col items-center px-3 py-2.5 rounded-xl border text-xs transition-colors ${isSelected ? 'border-gold-500 bg-gold-500/10 text-gold-400' : 'border-white/10 text-gray-500 hover:border-white/20'}`}>
                        <span className="uppercase opacity-60">{d.toLocaleDateString('en', { weekday: 'short' })}</span>
                        <span className="text-base font-bold mt-0.5">{d.getDate()}</span>
                        <span className="opacity-60">{d.toLocaleDateString('en', { month: 'short' })}</span>
                      </button>
                    )
                  })}
                </div>
              </div>
              {form.selectedDate && (
                <div>
                  <label className="text-xs text-gray-500 mb-2 block font-medium">Select time slot</label>
                  {loadingSlots ? (
                    <div className="flex items-center gap-2 text-gray-500 text-sm py-4">
                      <Loader2 size={16} className="animate-spin" /> Checking availability...
                    </div>
                  ) : (
                    <div className="grid grid-cols-4 gap-2">
                      {(availableSlots.length ? availableSlots : TIME_SLOTS.map(t => ({ time: t, available: true }))).map(({ time, available }) => (
                        <button key={time} type="button"
                          disabled={!available}
                          onClick={() => available && set('selectedTime', time)}
                          className={`py-2.5 rounded-xl text-xs border transition-colors ${!available ? 'border-white/5 text-gray-700 cursor-not-allowed' : form.selectedTime === time ? 'border-gold-500 bg-gold-500/10 text-gold-400' : 'border-white/10 text-gray-400 hover:border-white/20'}`}>
                          {time}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
              <div>
                <label className="text-xs text-gray-500 mb-1.5 block font-medium">Additional notes</label>
                <textarea className="input-dark resize-none" rows={3} placeholder="Treatments you offer, number of clients per month, specific questions..." value={form.notes} onChange={e => set('notes', e.target.value)} />
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-sm text-gray-400 mb-4">Review your booking details.</p>
              <div className="glass-card rounded-xl divide-y divide-white/5 text-sm">
                {[
                  ['Name', form.clientName], ['Email', form.email], ['Phone', form.phone],
                  ['Clinic', form.clinicName || '—'], ['Machine', form.machine],
                  ['Demo type', form.demoType], ['Date', form.selectedDate],
                  ['Time', form.selectedTime], ['Budget', form.budget || '—'],
                ].map(([label, val]) => (
                  <div key={label} className="flex justify-between py-3 px-4">
                    <span className="text-gray-500">{label}</span>
                    <span className="text-right text-gold-400 font-medium max-w-xs truncate">{val}</span>
                  </div>
                ))}
              </div>
              <label className="flex items-start gap-3 mt-4 cursor-pointer">
                <input type="checkbox" className="mt-0.5 accent-yellow-500" required />
                <span className="text-xs text-gray-500 leading-relaxed">
                  I agree to be contacted by El Tekniko regarding my inquiry and demo booking. View our privacy policy.
                </span>
              </label>
            </div>
          )}
        </div>

        {/* Footer actions */}
        {!success && (
          <div className="px-6 py-4 border-t border-white/5 flex justify-between items-center">
            <button
              onClick={() => setStep(s => Math.max(1, s - 1))}
              className={`flex items-center gap-1 text-sm text-gray-500 hover:text-white transition-colors ${step === 1 ? 'invisible' : ''}`}
            >
              <ChevronLeft size={16} /> Back
            </button>
            {step < 3 ? (
              <button
                onClick={() => setStep(s => s + 1)}
                disabled={
                  (step === 1 && (!form.clientName || !form.email || !form.phone)) ||
                  (step === 2 && (!form.machine || !form.selectedDate || !form.selectedTime))
                }
                className="btn-gold py-2.5 px-6 text-sm disabled:opacity-40 disabled:cursor-not-allowed"
              >
                Continue <ChevronRight size={16} />
              </button>
            ) : (
              <button onClick={handleSubmit} disabled={loading} className="btn-gold py-2.5 px-6 text-sm disabled:opacity-60">
                {loading ? <><Loader2 size={15} className="animate-spin" /> Booking...</> : 'Confirm Booking'}
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

function convertTo24h(time12: string): string {
  const [time, meridiem] = time12.split(' ')
  const [h, m] = time.split(':').map(Number)
  let hours = h
  if (meridiem === 'PM' && h !== 12) hours += 12
  if (meridiem === 'AM' && h === 12) hours = 0
  return `${String(hours).padStart(2, '0')}:${String(m || 0).padStart(2, '0')}`
}
