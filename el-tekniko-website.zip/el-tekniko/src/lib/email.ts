import { Resend } from 'resend'

const resend = new Resend(process.env.RESEND_API_KEY)

interface ConfirmationEmailParams {
  to: string
  name: string
  machine: string
  datetime: string
  demoType: string
  meetLink?: string | null
}

export async function sendConfirmationEmail(params: ConfirmationEmailParams) {
  const { to, name, machine, datetime, demoType, meetLink } = params

  const date = new Date(datetime)
  const formatted = date.toLocaleDateString('en-PH', {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
    hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Manila',
  })

  const gcalUrl = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(`El Tekniko Demo: ${machine}`)}&dates=${formatGCalDate(date)}/${formatGCalDate(new Date(date.getTime() + 45*60000))}&details=${encodeURIComponent(`Demo with El Tekniko\nMachine: ${machine}`)}&location=${encodeURIComponent(demoType === 'In-person' ? 'El Tekniko Showroom, Quezon City' : meetLink || 'Virtual')}`

  const html = `
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="margin:0;padding:0;background:#0A0A0A;font-family:system-ui,sans-serif;color:#ffffff;">
  <div style="max-width:560px;margin:0 auto;padding:40px 20px;">
    <div style="text-align:center;margin-bottom:32px;">
      <h1 style="font-size:24px;font-weight:700;margin:0;">
        El <span style="color:#C9A84C;">Tekniko</span>
      </h1>
      <p style="color:#666;font-size:13px;margin:8px 0 0;">Premium Aesthetic Machines · Philippines</p>
    </div>

    <div style="background:#111;border:1px solid rgba(255,255,255,0.08);border-radius:16px;padding:28px;margin-bottom:20px;">
      <div style="text-align:center;margin-bottom:24px;">
        <div style="width:56px;height:56px;background:rgba(201,168,76,0.15);border-radius:50%;display:inline-flex;align-items:center;justify-content:center;margin-bottom:12px;">
          <span style="font-size:24px;">✓</span>
        </div>
        <h2 style="font-size:20px;font-weight:700;margin:0 0 4px;">Demo Confirmed!</h2>
        <p style="color:#888;font-size:14px;margin:0;">Hi ${name}, you're all set.</p>
      </div>

      <table style="width:100%;font-size:14px;border-collapse:collapse;">
        ${row('Machine', machine)}
        ${row('Date & Time', formatted)}
        ${row('Demo Type', demoType)}
        ${demoType.includes('Virtual') && meetLink ? row('Meet Link', `<a href="${meetLink}" style="color:#C9A84C;">${meetLink}</a>`) : row('Location', 'El Tekniko Showroom, Quezon City, Metro Manila')}
        ${row('Duration', '45 minutes')}
      </table>
    </div>

    <div style="text-align:center;margin-bottom:20px;">
      <a href="${gcalUrl}" style="display:inline-block;background:#C9A84C;color:#000;font-weight:700;padding:13px 28px;border-radius:8px;text-decoration:none;font-size:14px;">
        + Add to Google Calendar
      </a>
    </div>

    <div style="background:#111;border:1px solid rgba(255,255,255,0.08);border-radius:12px;padding:20px;font-size:13px;color:#888;">
      <p style="margin:0 0 8px;font-weight:600;color:#fff;">Have questions?</p>
      <p style="margin:0;">WhatsApp us: <a href="https://wa.me/${process.env.NEXT_PUBLIC_WHATSAPP_NUMBER}" style="color:#C9A84C;">+63 9XX XXX XXXX</a></p>
      <p style="margin:4px 0 0;">Email: <a href="mailto:sales@eltekniko.com" style="color:#C9A84C;">sales@eltekniko.com</a></p>
    </div>

    <p style="text-align:center;color:#444;font-size:12px;margin-top:24px;">
      © ${new Date().getFullYear()} El Tekniko · Quezon City, Metro Manila, Philippines
    </p>
  </div>
</body>
</html>`

  await resend.emails.send({
    from: 'El Tekniko <noreply@eltekniko.com>',
    to,
    subject: `Demo Confirmed: ${machine} on ${date.toLocaleDateString('en-PH', { month: 'short', day: 'numeric', timeZone: 'Asia/Manila' })}`,
    html,
  })
}

export async function sendLeadNotification(lead: {
  name: string; email: string; phone: string; machine: string; source: string
}) {
  await resend.emails.send({
    from: 'El Tekniko Leads <noreply@eltekniko.com>',
    to: process.env.SALES_EMAIL!,
    subject: `New Lead: ${lead.name} — ${lead.machine}`,
    html: `
      <h2>New inquiry from ${lead.name}</h2>
      <p><strong>Machine:</strong> ${lead.machine}</p>
      <p><strong>Phone:</strong> ${lead.phone}</p>
      <p><strong>Email:</strong> ${lead.email}</p>
      <p><strong>Source:</strong> ${lead.source}</p>
    `,
  })
}

function row(label: string, value: string) {
  return `
    <tr>
      <td style="padding:10px 0;border-bottom:1px solid rgba(255,255,255,0.05);color:#888;width:40%;">${label}</td>
      <td style="padding:10px 0;border-bottom:1px solid rgba(255,255,255,0.05);color:#fff;font-weight:500;">${value}</td>
    </tr>`
}

function formatGCalDate(d: Date): string {
  return d.toISOString().replace(/[-:]/g,'').split('.')[0] + 'Z'
}
