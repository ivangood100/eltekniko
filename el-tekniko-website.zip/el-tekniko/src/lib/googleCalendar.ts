import { google } from 'googleapis'

const auth = new google.auth.GoogleAuth({
  credentials: {
    client_email: process.env.GOOGLE_CLIENT_EMAIL,
    private_key: process.env.GOOGLE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
  },
  scopes: ['https://www.googleapis.com/auth/calendar'],
})

export interface BookingDetails {
  clientName: string
  email: string
  phone: string
  clinicName: string
  machine: string
  demoType: string
  startTime: string
  notes?: string
}

export async function createBookingEvent(booking: BookingDetails) {
  const calendar = google.calendar({ version: 'v3', auth })

  const endTime = new Date(
    new Date(booking.startTime).getTime() + 45 * 60 * 1000
  ).toISOString()

  const isVirtual = booking.demoType.toLowerCase().includes('virtual')

  const event = await calendar.events.insert({
    calendarId: process.env.GOOGLE_CALENDAR_ID!,
    sendUpdates: 'all',
    conferenceDataVersion: isVirtual ? 1 : 0,
    requestBody: {
      summary: `El Tekniko Demo: ${booking.machine} — ${booking.clientName}`,
      description: [
        `Client: ${booking.clientName}`,
        `Clinic: ${booking.clinicName || 'N/A'}`,
        `Phone: ${booking.phone}`,
        `Email: ${booking.email}`,
        `Machine: ${booking.machine}`,
        `Demo Type: ${booking.demoType}`,
        `Notes: ${booking.notes || 'None'}`,
      ].join('\n'),
      location: booking.demoType === 'In-person'
        ? 'El Tekniko Showroom, Quezon City, Metro Manila'
        : 'Virtual (Google Meet link below)',
      start: { dateTime: booking.startTime, timeZone: 'Asia/Manila' },
      end: { dateTime: endTime, timeZone: 'Asia/Manila' },
      attendees: [
        { email: booking.email, displayName: booking.clientName },
        { email: process.env.SALES_EMAIL! },
      ],
      reminders: {
        useDefault: false,
        overrides: [
          { method: 'email', minutes: 1440 },  // 24h before
          { method: 'email', minutes: 120 },   // 2h before
          { method: 'popup', minutes: 60 },
        ],
      },
      ...(isVirtual && {
        conferenceData: {
          createRequest: {
            requestId: `eltekniko-${Date.now()}`,
            conferenceSolutionKey: { type: 'hangoutsMeet' },
          },
        },
      }),
    },
  })

  return event.data
}

export async function getAvailableSlots(date: string) {
  const calendar = google.calendar({ version: 'v3', auth })

  const res = await calendar.events.list({
    calendarId: process.env.GOOGLE_CALENDAR_ID!,
    timeMin: `${date}T00:00:00+08:00`,
    timeMax: `${date}T23:59:59+08:00`,
    singleEvents: true,
    orderBy: 'startTime',
  })

  const bookedTimes = res.data.items?.map(e => {
    const dt = e.start?.dateTime
    if (!dt) return null
    const d = new Date(dt)
    return `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`
  }).filter(Boolean) ?? []

  const allSlots = ['09:00','10:00','11:00','13:00','14:00','15:00','16:00','17:00']

  return allSlots.map(slot => ({
    time: formatTo12h(slot),
    available: !bookedTimes.includes(slot),
  }))
}

export async function cancelEvent(eventId: string) {
  const calendar = google.calendar({ version: 'v3', auth })
  await calendar.events.delete({
    calendarId: process.env.GOOGLE_CALENDAR_ID!,
    eventId,
    sendUpdates: 'all',
  })
}

export async function rescheduleEvent(eventId: string, newStartTime: string) {
  const calendar = google.calendar({ version: 'v3', auth })
  const newEndTime = new Date(new Date(newStartTime).getTime() + 45 * 60 * 1000).toISOString()
  const res = await calendar.events.patch({
    calendarId: process.env.GOOGLE_CALENDAR_ID!,
    eventId,
    sendUpdates: 'all',
    requestBody: {
      start: { dateTime: newStartTime, timeZone: 'Asia/Manila' },
      end: { dateTime: newEndTime, timeZone: 'Asia/Manila' },
    },
  })
  return res.data
}

function formatTo12h(time24: string): string {
  const [h, m] = time24.split(':').map(Number)
  const meridiem = h < 12 ? 'AM' : 'PM'
  const hours = h === 0 ? 12 : h > 12 ? h - 12 : h
  return `${hours}:${String(m).padStart(2,'0')} ${meridiem}`
}
